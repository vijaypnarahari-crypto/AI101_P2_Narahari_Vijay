---
name: source-check
description: Turn my course syllabi into one calendar with dated items, events, and due-date overlaps.
---

# Skill: source-check

Input: syllabi for my courses

Steps:
1. collect syllabi
2. extract every dated item
3. convert words like class 1 and week 1 to corresponding dates
4. add events
5. add fixed events
6. add dates for assignments, projects, and tests.
7. check for overlaps on due dates from my two courses
8. review and update the calendar every week

Check before acting: If any date is not clear in the syllabi, stop and ask me.