---
type: record-of-resistance
context: AI101
project: Syllabus to Calendar
date: 2026-10-21
record-number: 2
---

# Record of Resistance: Assignment choice boundary

**Course:** AI 101 and ANIM223  
**Project:** Syllabus to Calendar  
**Date:** 2026-10-21  
**Record #:** 2

---

## What AI Suggested

The agent said it could not choose which assignment I should start first. It offered to compare the remaining work on each assignment.

## Why I Rejected or Revised It

“I am upset that you cannot prioritize for me. I am genuinely unable to decide, so you have to help me.”

## What I Did Instead

I asked the agent to help me choose between the AI101 Capstone and ANIM223 Assignment 5, then asked to save this resistance. I have not chosen which assignment to start first.
