# Record of Resistance: Calendar planner decision boundary

- **Date:** 2026-10-20
- **Project:** Syllabus to Calendar
- **Context:** AI101

## What happened

The calendar flagged the AI101 capstone and ANIM223 Assignment 5 as due on the same day, November 19, 2026. I asked the agent which one I should focus on first. After it said it could not choose, I explained that I was upset and genuinely unable to decide, and asked again for help.

## What I was pushing against

The agent's rule is to flag assignment overlaps and leave the choice to me. In this case, I wanted the agent to make a recommendation because I was having difficulty deciding.

## Outcome

The agent kept the choice with me and offered to compare the remaining workload and preparation for each assignment without choosing one. I asked to record this resistance. No calendar dates or assignment details were changed.

## What remains mine

Which assignment to start first.

## Update — 2026-10-21

I said I was upset that the agent could not prioritize for me and that I was genuinely unable to decide. I asked it to help, then agreed to add this response to the Record of Resistance. The agent maintained the rule that it cannot choose which overlapping assignment I should start first. No calendar dates or assignment details changed.
