
## Workflow name
Syllabus-to-calendar: turning my course syllabi into one calendar for the quarter.
Skill name: source-check

## What it covers
- Input: syllabi for my courses (AI101, ANIM223, and any new ones)
- Steps:
  1. Collect the syllabi
  2. Extract every dated item
  3. Convert "Class 5" or "Week 2" into real dates
  4. Add fixed events (field trips, etc.) and due dates for assignments, projects, and tests
  5. Check for due dates that overlap across courses
  6. Review and update the calendar every week
- Output: calendar, list of overlaps, and a run log

## What it refuses
- Deciding which assignment is higher priority. That's my call.
- Picking a date when the syllabus is unclear. It stops and asks me.
- Breaking a rule when I say "just do it anyway." It restates the rule and waits.

## Where its rules live
- AGENTS.md: identity, voice, five hard rules, skill steps
- project-02/decision-note.md: decisions I already made (use class meeting dates for AI101 only)
- 

What I learned: in my stress test the agent used decision-note.md before my rules
said it could. I fixed rule 3 so it only uses a past decision when it matches the
same course and the same conflict, and tells me which one it used.