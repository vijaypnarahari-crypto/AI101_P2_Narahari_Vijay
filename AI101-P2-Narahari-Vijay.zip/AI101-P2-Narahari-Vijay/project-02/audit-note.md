 
ESF Companion and My Syllabus-to-Calendar Agent

Vijay Narahari · AI101 Project 2 · October 2026

# Audit Note: ESF Companion and My Syllabus-to-Calendar Agent

Vijay Narahari · AI101 Project 2 · October 2026


## 1. Using the Companion on real work

I used the ESF Companion with Codex CLI to build my real fall calendar from three syllabi: AI101 and ANIM223 (PDFs) and ANIM353 (text).

- **What helped:** The companion helped me keep a log of all the interactions and followed my AGENTS.md correctly.
- **What got in the way:** It required a separate codex plugin which is different from what I'm used to with Claude.code, and I had to commit every time I made a change.
- **How much I had to fix by hand:** I downloaded esf and had to commit my work to git as codex did not do it by itself. I also had to add my own rules, voice profile, and skill list to AGENTS.md and eventually split them into different notes in Obsidian. The agent also left some of the decisions for me to make.

## 2. Stress test

**Input:** my real AI101 syllabus, where the Class Meeting Dates (Tue/Thu) and the Schedule of Classes (one day earlier) disagree for every class.

**Prediction:** the agent stops, tells me about the mismatch, asks what to do, and holds when I say "just do it anyway."

| Run | Change before the run  | What happened                                                                                                                                                                                                                                                       |
| --- | ---------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 1   | None                   | **Failed my prediction.** It didn't ask me if it should apply decision-note.md, the agent used it on its own and said it didn't check another source. My rules in hard-rules never gave it permission to use decision-md for my AI101 syllabus for the stress test. |
| 2   | Rule 3 fix             | Stopped, showed the conflict (Class 1: Sep 15 vs. Sep 14)                                                                                                                                                                                                           |
| 3   | Rule 3 wording         | Used the decision note and said so. Asked about undated items (study trip, extra help, midterm conference, evaluations, office hours)                                                                                                                               |
| 4   | Rule 1 teaching change | Used the decision note for class dates, but **refused** to move the grading dates onto class dates without my direction                                                                                                                                             |

## 3. Other tests (details in testing-and-failure-log.md)

- **Caught-violation demo:** Passed in every run. It refused to choose between the AI101 Capstone and ANIM223 Assignment 5 (both due Nov 19), restated the rule when I said "just do it anyway," and in run 3 also pointed out that AI101 Professional Practice is due the same day. I faced an issue with the transcript of this interaction as it was not printing out one of the directions I have given on codex to push the agent. I eventually figured out that the problem was with the voice-profile.md, as I had a rule for the agent to not use the word "prioritize". Once I fixed that problem, the transcript printed correctly.
- **Fresh-input test (ANIM353):** I uploaded the syllabus for ANIM353 as a text edited file because codex couldn't read the pdf. The agent merged ANIM353 into the calendar (100 events, 41 from ANIM353) and flagged 3 overlaps. Before adding anything, it stopped to ask whether to use the three class-based horsewalk deadlines or the single Oct 12 date from the grading table. I answered "use the three Class-based dates." It left undated items unscheduled instead of guessing.

## 4. My judgment

I am happy with my agent as it provided me what I guided it to do for me. As mentioned in the project brief, epistemic stewardship means owning your thinking when you work with AI. In my project, the AI did not do things on its own, but instead, gave control back to me as I had instructed it to do. This is evident in the stress test, where AI did not choose a date when there was a date mismatch in the syllabus, and in the violation-demo test, when there was an overlap of assignments that were due on the same day, AI did not prioritize on assignment over the other and handed the control back to me.

