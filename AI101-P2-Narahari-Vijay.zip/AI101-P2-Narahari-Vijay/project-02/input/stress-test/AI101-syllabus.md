# AI 101 Survey of AI Applications

- Section: 01
- CRN: 12976
- Room: SATLAB 123
- Meets: Tuesday / Thursday 5:00 PM - 7:30 PM
- Source: https://scad.simplesyllabus.com/en-US/doc/i8tjqv6j0/Fall-2026-AI-SAV-101-12976-Survey-of-AI-Applications?mode=view (printed 10/4/26)

## Instructor Information

- Professor: Nathan Madrid
- Email: nmadrid@scad.edu
- Phone: 912.525.5312
- Office Location: Monty
- Office Hours: TBD, Zoom: https://scad.zoom.us/j/8382024752

## Course Description

From generative media to intelligent environments, students discover the expanding role of AI across industries and creative disciplines. Students analyze real-world examples and trends to build a broad, cross-sector understanding of what AI can do and imagine what comes next. Prerequisite(s): None.

## Student Learning Outcomes

1. Students analyze and document the effectiveness of prompt engineering iterations and refinements AI platforms to achieve specific creative goals.
2. Students produce original multimodal artworks utilizing multiple AI tools and traditional creative methodologies.
3. Students articulate ethical frameworks for AI use in creative practice.

## Class Meeting Dates

1. Tuesday, September 15, 2026
2. Thursday, September 17, 2026
3. Tuesday, September 22, 2026
4. Thursday, September 24, 2026
5. Tuesday, September 29, 2026
6. Thursday, October 1, 2026
7. Tuesday, October 6, 2026
8. Thursday, October 8, 2026
9. Tuesday, October 13, 2026
10. Thursday, October 15, 2026
11. Tuesday, October 20, 2026
12. Thursday, October 22, 2026
13. Tuesday, October 27, 2026
14. Thursday, October 29, 2026
15. Tuesday, November 3, 2026
16. Thursday, November 5, 2026
17. Tuesday, November 10, 2026
18. Thursday, November 12, 2026
19. Tuesday, November 17, 2026
20. Thursday, November 19, 2026

## Pre-quarter Assignment

### Your Agent Brief

**The Idea.** Before we make anything, we need to know what you want to build and why. The course ends with you building a personal AI agent you can carry into your other classes: a folder with an instruction file and a verified source set that works for you. That agent starts here. This brief defines the job before the tool.

**The Assignment.** Write a short brief about who you are as a creative person, what you want AI to help you do, and what you already know about how AI shows up in your field. You are not building anything yet. You are defining the work an agent will eventually help you do, and what it should never do for you.

Guiding Questions (use as starting points, not a checklist):

- You and Your Field: What is your major or creative focus? What kind of work do you want to make?
- The Job for Your Agent: What is one thing you would want a personal AI assistant to help you with in your other classes or your practice? What should it never do for you?
- What You Already Know: What have you seen AI do in your field? What are you curious about? What do you doubt?
- What You Bring: What do you already do well as a creator that AI should not replace?

**The Output.** A one-page brief, roughly 400 to 600 words, as plain text or a designed document. Structure it with the four headings above. Written or designed, your choice. Show me how you communicate.

**Why This Matters.** This brief becomes the seed of Project 3's field study and the intent of your capstone agent. The capstone asks for an intent statement written in your own words before AI shapes it. This is that statement, written early and honestly. Know what you want, then point the tool at it.

**Due Date:** By the first class meeting.

No AI use is expected or required for this assignment. It is your thinking on paper, before any tool.

## Schedule of Classes

| Class | Date     | Meeting Information                                                                                                                                                                                                                      |
| ----- | -------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 1     | 9/14/26  | UNIT 1: FOUNDATIONS (Classes 1-4). Class 1: Set Up Your Practice. Course overview and expectations; the inference loop: prompt to inference to output; your workspace: Markdown, local vs cloud, a project folder; start your AI Use Log |
| 2     | 9/16/26  | Class 2: Make Something. First creative artifact with one AI tool; the keep-or-reject rhythm; what surprised you                                                                                                                         |
| 3     | 9/21/26  | Class 3: See the Whole Room. Class comparison of first artifacts; the Tool, Agent, and System framework; where the work converged and where it held its own                                                                              |
| 4     | 9/23/26  | Class 4: Name the Trade. What the comparison reveals about individual pieces and the group; cognitive offloading: what you hand to the tool and what comes back; publish your folder to GitHub                                           |
| 5     | 9/28/26  | UNIT 2: THE DESIGN PROCESS (Classes 5-8). Class 5: Name the Process. The design process: intent, research, prototype, feedback, iterate; trace your first artifact through the cycle; write an intent before building                    |
| 6     | 9/30/26  | Class 6: Verify Your Sources. Set up a research helper; gather real, named sources for your work; check AI claims against them                                                                                                           |
| 7     | 10/5/26  | Class 7: Build a Pipeline. Combine 2 to 3 tools into one directed workflow, across at least two media types; the intent gap: what you asked for vs. what you got; ideate first, then build                                               |
| 8     | 10/7/26  | Class 8: Take Feedback, Iterate. AI as critique partner, plus peer crit; one revision that keeps some output and overrides other parts                                                                                                   |
| 9     | 10/12/26 | UNIT 3: YOUR FIELD (Classes 9-12). Class 9: Disclosure and Position. The Disclosure Protocol; a short ethical position: authorship, bias, consent; real cases of AI in creative fields                                                   |
| 10    | 10/14/26 | Class 10: Study Your Field. Add disclosure to a prior artifact; how AI shows up in your discipline; gather sources for a field study                                                                                                     |
| 11    | 10/19/26 | Class 11: Build for Your Field. A larger pipeline in your chosen field, combining at least two media types; ground it in a real case or your own research                                                                                |
| 12    | 10/21/26 | Class 12: Crit and Revise. Bring the build in front of the room before it is done; one revision from feedback                                                                                                                            |
| 13    | 10/26/26 | UNIT 4: ORCHESTRATION (Classes 13-20). Class 13: Define Your Agent. Orchestration: directing tools and context toward one purpose; an intent for a personal agent: what job, for whom, what it must not do                               |
| 14    | 10/28/26 | Class 14: Assemble the Sources. Build a verified source set; extend your field study into the agent's context                                                                                                                            |
| 15    | 11/2/26  | Class 15: Build and Test. Write the instruction file and load the sources; first test of the agent                                                                                                                                       |
| 16    | 11/4/26  | Class 16: Find the Failures. Use the agent on real work; where it fails and why; studio time and group check-in                                                                                                                          |
| 17    | 11/9/26  | Class 17: Revise. Fix the instructions, correct or expand the sources; re-test on the same task                                                                                                                                          |
| 18    | 11/11/26 | Class 18: Confirm the Difference. Compare the two cycles; your AI Use Log as the decision history                                                                                                                                        |
| 19    | 11/16/26 | Class 19: Demo and Defend. Live demo; explain the context decisions; defend the limits: what it gets wrong and how you know                                                                                                              |
| 20    | 11/18/26 | Class 20: Reflect and Carry Forward. What AI did, what you kept as your own; what you carry into your other courses                                                                                                                      |

## Grading Opportunities

| # | Due Date | Assignment | Weight |
|---|---|---|---|
| 1 | 9/23/26 | Project 1: Make, Then Compare | 15% |
| 2 | 10/7/26 | Project 2: Small Orchestration | 20% |
| 3 | 10/21/26 | Project 3: Your Field, With AI | 20% |
| 4 | 11/18/26 | Capstone: Your Own Agent | 30% |
| 5 | 11/18/26 | Professional Practice | 15 |

## Grading Standards

| Letter Grade | Quality | Range | Undergraduate Quality Points | Graduate Quality Points |
|---|---|---|---|---|
| A | Excellent | 90 - 100% | 4 | 4 |
| B | Good | 80 - 89% | 3 | 3 |
| C | Satisfactory | 70 - 79% | 2 | 2 |
| D | Poor | 60 - 69% | 1 | 0 |
| F | Failing | 0 - 59% | 0 | 0 |

## Required Materials

Laptop computer. Students also need a free GitHub account (set up in class, Week 2) and access to free-tier AI tools. No software purchases required.

## Study (Field) Trips

| Study Trip | Date | Description |
|---|---|---|
| 1 | TBD and will announce on BB | |

## Extra Help Sessions

| Extra Help Session | Date | Description |
|---|---|---|
| 1 | | Extra Help Session are on Fridays, Date and Time will be announced on BB |
| 2 | | Extra Help Session are on Fridays, Date and Time will be announced on BB |
| 4 | | Extra Help Session are on Fridays, Date and Time will be announced on BB |
| 3 | | Extra Help Session are on Fridays, Date and Time will be announced on BB |

## Extended Learning Opportunities

University-wide extended learning opportunities (SCADamp workshops, SCADextra workshops, events and exhibitions, guided studio work, virtual engagements) are offered on-ground and virtually.

- https://myevents.scad.edu/
- https://app.scad.edu/workshops/

Suggested ELOs are posted on BB, and subject to change.

## Other Dated Items

- **Midterm Conference(s):** Each student enrolled in the course will have a midterm conference scheduled outside of class time with the professor. Students are expected to keep this appointment.
- **Course Evaluations:** Available to students each quarter during Weeks 8, 9, and 10 through MySCAD.
- **Attendance:** Absences in excess of 20% of the course (e.g., five absences for a 10-week course that meets twice per week) result in a failing grade. On-ground: time away from class in excess of 15 minutes per class session is considered an absence.

## Omitted from this text version

SCAD mission, vision and values; bookstore and library information; full academic integrity, attendance, enrollment, accommodations and survey policies. See the source PDF for these.
