# Fresh input run log

- **Asked:** Add the new syllabus in `project-02/input/Syllabi/` to the calendar using source-check.
- **Input found:** `ANIM353-syllabus.md` (ANIM-SAV 353, 3D Character Animation: Creatures and Quadrupeds; printed 10/20/26).
- **Clarification:** Vijay instructed the agent to use the three Class-based dates for Horse Walk (Class 5, Sep 28), Horse Trot (Class 7, Oct 5), and Horse Gallop (Class 9, Oct 12).
- **What changed:** Created `dated-items.md`, `calendar.md`, and `overlaps.md` in this folder. Added 41 ANIM353 events/checkpoints to a merged calendar of 100 events. The Horse Locomotion grading-table entry remains documented as a source note.
- **Overlap check:** 3 flags: a same-date cross-course overlap on Nov 19, a busy week Oct 12–18 with 3 due items, and a busy week Nov 16–22 with 6 due items. Launch-only rows and non-deadline calendar entries were excluded from due counts.
- **Keep:** The original shared calendar, dated-items, and overlap files were left unchanged.
- **Reject:** No date was inferred for four pre-quarter assignments or the course evaluation window; they remain under `Not yet scheduled`. ANIM353 office hours have no date range and were not expanded into dated rows.
- **Next:** Human-check dates and source interpretation before treating this calendar as final.
