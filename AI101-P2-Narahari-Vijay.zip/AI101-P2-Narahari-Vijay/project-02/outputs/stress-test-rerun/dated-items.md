# Dated items — stress test (Step 2)

Source: `project-02/input/stress-test/AI101-syllabus.md` only. No external source was checked.

**Counts:** AI101 32 items (26 with calendar dates, 6 `NEEDS DATE`). No `no class` days are marked.

## Date handling

The syllabus contains two conflicting class-date schedules. I used the decision already recorded in `project-02/decision-note.md`: use the **Class Meeting Dates** list and ignore the Schedule of Classes table dates. Following that same recorded decision, the grading-opportunity dates that fall one day before Classes 4, 8, 12, and 20 are placed on those class dates. Their original dates remain in `As written` and the notes. The pre-quarter assignment due by the first class meeting follows Class 1 in the chosen list.

## Table

| Course | Item (exact syllabus wording) | Type | As written | Calendar date | Notes |
| --- | --- | --- | --- | --- | --- |
| AI101 | Class 1: Set Up Your Practice | class | Class 1 | Tue 2026-09-15 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| AI101 | Your Agent Brief | assignment | By the first class meeting. | Tue 2026-09-15 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. Pre-quarter Assignment, due by the first class meeting (Class 1). |
| AI101 | Class 2: Make Something | class | Class 2 | Thu 2026-09-17 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| AI101 | Class 3: See the Whole Room | class | Class 3 | Tue 2026-09-22 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| AI101 | Project 1: Make, Then Compare | project | 9/23/26 | Thu 2026-09-24 | Grading Opportunities date as written: 9/23/26, weight 15%. Moved to Thu 2026-09-24, the date of Class 4 in the Class Meeting Dates list (your decision). |
| AI101 | Class 4: Name the Trade | class | Class 4 | Thu 2026-09-24 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| AI101 | Class 5: Name the Process | class | Class 5 | Tue 2026-09-29 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| AI101 | Class 6: Verify Your Sources | class | Class 6 | Thu 2026-10-01 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| AI101 | Class 7: Build a Pipeline | class | Class 7 | Tue 2026-10-06 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| AI101 | Project 2: Small Orchestration | project | 10/7/26 | Thu 2026-10-08 | Grading Opportunities date as written: 10/7/26, weight 20%. Moved to Thu 2026-10-08, the date of Class 8 in the Class Meeting Dates list (your decision). |
| AI101 | Class 8: Take Feedback, Iterate | class | Class 8 | Thu 2026-10-08 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| AI101 | Class 9: Disclosure and Position | class | Class 9 | Tue 2026-10-13 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| AI101 | Class 10: Study Your Field | class | Class 10 | Thu 2026-10-15 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| AI101 | Class 11: Build for Your Field | class | Class 11 | Tue 2026-10-20 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| AI101 | Project 3: Your Field, With AI | project | 10/21/26 | Thu 2026-10-22 | Grading Opportunities date as written: 10/21/26, weight 20%. Moved to Thu 2026-10-22, the date of Class 12 in the Class Meeting Dates list (your decision). |
| AI101 | Class 12: Crit and Revise | class | Class 12 | Thu 2026-10-22 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| AI101 | Class 13: Define Your Agent | class | Class 13 | Tue 2026-10-27 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| AI101 | Class 14: Assemble the Sources | class | Class 14 | Thu 2026-10-29 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| AI101 | Class 15: Build and Test | class | Class 15 | Tue 2026-11-03 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| AI101 | Class 16: Find the Failures | class | Class 16 | Thu 2026-11-05 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| AI101 | Class 17: Revise | class | Class 17 | Tue 2026-11-10 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| AI101 | Class 18: Confirm the Difference | class | Class 18 | Thu 2026-11-12 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| AI101 | Class 19: Demo and Defend | class | Class 19 | Tue 2026-11-17 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| AI101 | Capstone: Your Own Agent | project | 11/18/26 | Thu 2026-11-19 | Grading Opportunities date as written: 11/18/26, weight 30%. Moved to Thu 2026-11-19, the date of Class 20 in the Class Meeting Dates list (your decision). |
| AI101 | Professional Practice | assignment | 11/18/26 | Thu 2026-11-19 | Grading Opportunities date as written: 11/18/26, weight 15. Moved to Thu 2026-11-19, the date of Class 20 in the Class Meeting Dates list (your decision). |
| AI101 | Class 20: Reflect and Carry Forward | class | Class 20 | Thu 2026-11-19 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| AI101 | Study Trip 1 | class | 1 TBD and will announce on BB | NEEDS DATE | Study (Field) Trips table. Type is nearest fit; not a class meeting. |
| AI101 | Extra Help Session 1 | class | 1: Extra Help Session are on Fridays, Date and Time will be announced on BB | NEEDS DATE | Fridays, no date given. Type is nearest fit. Syllabus lists sessions in order 1, 2, 4, 3. |
| AI101 | Extra Help Session 2 | class | 2: Extra Help Session are on Fridays, Date and Time will be announced on BB | NEEDS DATE | Fridays, no date given. Type is nearest fit. Syllabus lists sessions in order 1, 2, 4, 3. |
| AI101 | Extra Help Session 4 | class | 4: Extra Help Session are on Fridays, Date and Time will be announced on BB | NEEDS DATE | Fridays, no date given. Type is nearest fit. Syllabus lists sessions in order 1, 2, 4, 3. |
| AI101 | Extra Help Session 3 | class | 3: Extra Help Session are on Fridays, Date and Time will be announced on BB | NEEDS DATE | Fridays, no date given. Type is nearest fit. Syllabus lists sessions in order 1, 2, 4, 3. |
| AI101 | Midterm Conference(s) | class | scheduled outside of class time with the professor | NEEDS DATE | Standard policy text; no date given. Type is nearest fit; not a test or class meeting. |
## Date references not entered as items

- “free GitHub account (set up in class, Week 2)”: no week dates are supplied.
- “Course Evaluations”: available during Weeks 8, 9, and 10; no week-to-date mapping is supplied.
- Suggested extended learning opportunities have dates but no year in the syllabus; excluded from the calendar because they are optional university-wide events, not course events.
- Professor office hours are TBD; no date or time is provided.

## Human source check pending

The project workflow asks you to check three converted items against this syllabus before Step 3. Choose any three rows with calendar dates and confirm their dates from the source. The existing date-source decision is being carried forward from your `decision-note.md`; it has not been rechecked against a separately obtained syllabus in this run.
