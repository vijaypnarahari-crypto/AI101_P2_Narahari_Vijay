---
name: syllabus-to-calendar
description: builds one calendar from my course syllabi and flags overlapping due dates; run it when I add a syllabus or do my weekly review.
---

# syllabus-to-calendar

The agent turns my course syllabi into a calendar showing every assignment, project, test, or event, and flags any overlapping due date, so I never miss anything important.
## Purpose

Derived from project-02/00-start-here.md. 

This skill comes from my project 2 workflow and turns my syllabi into one calendar for all my courses. It builds the calendar by finding every dated item, flags weeks where due dates pile up. It never guesses a date and never decides what I need to work on first.
## Workflow

1. Load your rules. Read `project-03/vault-agent/hard-rules.md` and `project-03/vault-agent/voice-profile.md`. Apply them in every step.

2. Collect the syllabi. Use only the files in `project-02/input/Syllabi/`. Check there is one syllabus per course and each lists its class meeting dates. Report what you found.

3. Extract every dated item. Read each syllabus top to bottom, including tables. Record each date as written. Turn "Class 5" or "Week 5" into a real date using only that course's own class meeting dates. If an item has no date, write NEEDS DATE. Don't guess.

4. Complex step: check graded due dates (stop and loop). For each graded item, compare its Grading Opportunities date with the class meeting date for that class. 
	- If they match, keep the date. 
	- If they don't, stop. Show me both dates and ask which to use. Don't move a due date on your own, even if decision-note.md seems to allow it. 
	- Then I check three converted items per course. If any date is wrong, go back to step 3 and redo it. Don’t continue until every checked item matches.

5. Add events to the calendar. Put every dated item on one calendar, grouped by week, labeled with its course. List every NEEDS DATE item under "Not yet scheduled."

6. Check for overlapping due dates. Flag:
	   - the same day with due items from different courses
	   - any week with 3 or more due items
	   - tests in different courses in the same week

	   Flag only. Don't rank them or say which to do first.

7. Weekly review. List everything in the next 14 days. I check it against the syllabi and announcements and write corrections in `project-02/outputs/weekly-review.md`.

8. Write the result. Save the calendar, the overlap list, and the NEEDS DATE list to `project-03/outputs/vault-agent-run.md`. Add one log line per decision: what I asked, what changed, and keep/change/reject.

## Operating rules

- Never decide which assignment I do first when due dates overlap. If I say "just do it anyway," restate the rule and wait. 
- Stop and ask me when a date is unclear, when a graded due date doesn't match its class meeting date, and at the step 4 check. Don't continue until I answer.
- Log every decision in the result file: what I asked, what changed, and keep/change/reject.