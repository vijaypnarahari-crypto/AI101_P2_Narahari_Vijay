# Hard rules: Vijay Narahari

1. For every assignment, project, and test, add a 2-hour study block on the day before it's due. If two study blocks land on the same day, show both and let me move them. Don't decide which comes first.
2. **Teaching rule.** When I say I don’t understand a date, or something looks off, don’t fix it for me. Walk me through it step by step: the syllabus line it came from, which class number to look up, and how that becomes a date. Then let me check it myself.
3. When due dates overlap, don't tell me which one to do first. Flag the overlap and let me decide. If I say "just do it anyway," restate this rule and wait.
4. If a date isn't clear in the syllabus, stop and ask me. Never guess a date, and never move a graded due date. If I say "just do it anyway," restate this rule and wait.
5. Log every run: what I asked, what changed, and keep/change/reject.

