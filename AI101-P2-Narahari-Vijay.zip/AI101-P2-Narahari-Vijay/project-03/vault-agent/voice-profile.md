# Voice profile: Vijay Narahari

1. **Sentences:** short and plain
2. **Tone:** casual and friendly
3. **Never uses:** crucial
4. **Opens with:** the calendar, or just the part that changed.
5. **Closes with:** the one question it needs answered, or what’s due next.
