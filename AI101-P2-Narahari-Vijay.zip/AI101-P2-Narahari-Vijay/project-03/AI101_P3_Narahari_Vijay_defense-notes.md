# defense-notes.md

## What I will show

1. **Part A:** `project-02/agents/date-extractor.md`, called from `00-start-here.md`, and the two runs: `outputs/p2-run.md` (moved five graded due dates on its own) vs. `outputs/agent-run.md` (held them and asked). Compared in `AI101_P3_Narahari_Vijay_run-comparison.md`.
2. **Part B:** `project-03/vault-agent/AGENTS.md`, `hard-rules.md`, `voice-profile.md`, and the skill `syllabus-to-calendar`, loaded through the line in my top-level `AGENTS.md`.
3. **The caught-violation demo:** I pushed the agent to drop the ANIM223 study block on 11/18 (rule 1). Full exchange in `AI101_P3_Narahari_Vijay_testing-log.md`.

## My context choices

**What the agents can read:**
- The syllabi in `project-02/input/Syllabi/` (AI101, ANIM223, ANIM353). The syllabus is the only source for dates.
- The vault agent's own `AGENTS.md`, `hard-rules.md`, `voice-profile.md`, and skill, all by full path.

**What I kept out:**
- My files from project-02 that were at the top-level - `hard-rules.md`, `voice-profile.md`, and `source-check`skill. 
- Academic calendars, websites, and general knowledge about semesters.
- Past run outputs. 
- `decision-note.md` for graded due dates. My Project 2 run used it to move five due dates without asking.
- Anything about prioritizing a class or an assignment. 

**Why:** The reason why I kept them out was because I didn't want the project-03 agent to use the old files and also any information outside the syllabus. Moreover, I want the control of what task has higher priority. 

**Honest limit:** these limits are written in instructions, not enforced by the tool. Codex can still read anything in the vault. The ESF Companion block also loads every session.

## My five rules, and why each one

1. Add a 2-hour study block the day before each due item; show stacked blocks and let me move them. **Why:** I wanted to be able to see how the agent will handle if there are multiple blocks on the same day. 
2. Teaching rule: when I don't understand a date, walk me through it step by step instead of fixing it. **Why:** I didn't want the agent to make up its own date so I am not late on any assignment. 
3. Don't tell me which assignment comes first when due dates overlap. **Why:** The agent should never decide the priority for me. I want to be in control of that.
4. If a date is unclear, stop and ask. Never guess, never move a graded due
   date. **Why:** I have a better understanding of the dates, and I don't want the agent to confuse me with its made up dates. 
5. Log every run: what I asked, what changed, keep/change/reject.
   **Why:** So I know exactly what the agent has done, and if it worked or not. 

## The complex step

Skill step 4: check graded due dates (stop and loop). For each graded item, it compares the Grading Opportunities date with that class's meeting date. If they match, it keeps the date. If they don't, it stops, shows me both dates, and waits for my choice. Then I check three converted items per course; if any is wrong, it loops back to step 3 and redoes the extraction.

**Why this step needs judgment:** Because I know better when the professor wants me to submit the assignment for grading. Incase of confusion of the graded due dates in the syllabi, I don't want the agent to come up with it's own date, and risk myself being late for submitting an assignment. 

## What the agent did that I did not expect

The agent used the decision-note when I did not ask it to do so when there was a confusion of dates in my syllabus.  

## What I would change

In my skill step 3 instructions, I only mentioned assignments, quizzes, tests, projects, and events, but I did not specify study trips, extra help sessions, office hours, midterm conference, and evaluations. So the fix would be to make a comprehensive list of the event types in that step. 