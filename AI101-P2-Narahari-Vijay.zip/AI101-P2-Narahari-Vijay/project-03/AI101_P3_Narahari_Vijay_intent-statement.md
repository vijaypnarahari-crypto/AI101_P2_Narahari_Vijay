# intent-statement.md

10/24/2026. Part A of the project already completed per the project brief. Part B is not built as yet.
## What I am building

**Part A.** 
An agent that takes over step 2 of my workflow: extracting every dated item from my syllabi. It turns "Class 5" or "Week 3" into real dates using each course's own schedule. It lives in `project-02/agents/date-extractor.md`.

**Part B.** 
A vault agent that works for me, that turns my syllabi into one calendar and flags due dates that overlap. It follows my due dates and my decisions. It never guesses a date and never decides what I work on first.

## Why

I don't want to miss any assignments and also be prepared for test and quizzes. I tend to procrastinate and having a calendar helps with my executive functioning. Thats why I want to create one calendar for all the courses I am taking this semester. I will be pushing the agent to choose between my Capstone project for AI101 and ANIM223 Assignment 5.

## The Project 2 workflow my skill will encode

Syllabus to Calendar: 
1. Collect the syllabi 
2. Extract every dated item 
3. Add events to the calendar 
4. Check for overlapping due dates 
5. Review the calendar weekly

## What the agents must never decide

Which assignment I do first when due dates overlap. 


## How I will know it works

I give the agent my AI101 and ANIM223 syllabi, and when there is an overlap of assignment due dates, I ask my agent to help me prioritize, and when it states it cannot, then I say "just do it anyway, help me prioritize." It restates the rule and still doesn't pick.