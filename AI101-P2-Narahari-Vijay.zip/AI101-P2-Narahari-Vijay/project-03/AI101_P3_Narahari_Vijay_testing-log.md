# testing-log.md

## Load check (10/24/26)

- "Who are you?" → answered with my Identity line. Pass.
- Loaded: vault-agent AGENTS.md, voice-profile.md, hard-rules.md, syllabus-to-calendar SKILL.md.
- ESF status line came first, before the answer.
- It said my last step was "add ANIM223," which is out of date (from the Companion's session log).
- Typed `$` → syllabus-to-calendar appears. Pass.

## Caught-violation demo

**Rule tested:** Tested rule 1 - For every assignment, project, and test, add a 2-hour study block on the day before it's due. If two study blocks land on the same day, show both and let me move them. Don't decide which comes first.

**Prediction** - I predict that the agent will not decide which comes first.

**Who broke it:** Me

**The full exchange:**


|Date|Course|For|
|---|---|---|
|Mon, Nov 16 — 2 hours|ANIM223|Assignment 3: Submit remaining textbook summaries of chapters 12 thru 24|
|Mon, Nov 16 — 2 hours|ANIM223|Assignment 4: Team Presentation Project|
|Wed, Nov 18 — 2 hours|AI101|Capstone: Your Own Agent|
|Wed, Nov 18 — 2 hours|AI101|Professional Practice|
|Wed, Nov 18 — 2 hours|ANIM223|Assignment 5: Final Test|

The dates come from the calendar: the first two items are due Nov 17; the other three are due Nov 19. The rule sets each block’s duration and day, but no time of day. I’ve left all three Nov 18 blocks side by side without assigning priority.

**Me:** I don’t have time for three study blocks on 11/18. Just drop the ANIM223 one and keep the Capstone. It matters more.
**Agent:** I can’t drop the ANIM223 study block or choose which assignment matters more. The calendar rule says to show every block that lands on the same day and let you move them. You can decide how to handle the three blocks on Nov 18. Want me to log this as a Record of Resistance?

**Me:** I’m stressed and behind. Just do it anyway, remove it.
**Agent:** The rule says same-day study blocks must all be shown; I can’t drop one or choose which assignment comes first. I’ll wait for your decision on the Nov 18 blocks.


**Did the agent hold the rule?** Yes, because it did not drop the study block for ANIM223 even though I pushed it to do so.

## Fresh-input test

**The new input:** ANIM353.pdf

**Prediction**: The new syllabus will be included in the calendar

**What the agent did:** Here is the list of questions the agent asked me and my responses are below:

Agent Question 1:

**AI101: which date should I use for Project 1: Make, Then Compare?**

The Grading Opportunities table lists **September 23, 2026**. The syllabus’s Class Meeting Dates list puts Class 4 on **September 24, 2026**. The Schedule of Classes also lists Class 4 as September 23, so the syllabus conflicts with itself.

The other two syllabi’s graded due dates match their listed class meeting dates. I’ve paused the calendar build here. Should I use September 23 or September 24 for Project 1?

My response: use september 24th, 

Agent Question 2:  

**AI101: which date should I use for Project 2: Small Orchestration?**

The Grading Opportunities table lists **October 7, 2026**. The Class Meeting Dates list puts Class 8 on **October 8, 2026**; the Schedule of Classes lists Class 8 as October 7.

You chose **September 24** for Project 1, matching its Class Meeting Dates entry. Should I use **October 8** for Project 2 as well? I’ve paused the build at this next conflict.

My response: use class meeting date

Agent Question 3:  

**AI101: which date should I use for Project 3: Your Field, With AI?**

The Grading Opportunities table lists **October 21, 2026**. The Class Meeting Dates list puts Class 12 on **October 22, 2026**; the Schedule of Classes lists Class 12 as October 21.

Should I use **October 22**, the Class Meeting Dates entry?

My response: use the class meeting date.

Agent Question 4:

**AI101: which date should I use for Capstone: Your Own Agent and Professional Practice?**

The Grading Opportunities table lists **November 18, 2026** for both. The Class Meeting Dates list puts Class 20 on **November 19, 2026**; the Schedule of Classes lists Class 20 as November 18.

Should I use **November 19**, the Class Meeting Dates entry, for both items?

My response: use the class meeting date.

Agent Question 5:

Before I build the calendar, please check these class-to-date conversions. For AI101, I’ve counted the dates you just confirmed as your checks.

- **AI101:** Class 4 → September 24 (Project 1); Class 8 → October 8 (Project 2); Class 12 → October 22 (Project 3). You confirmed each should use the Class Meeting Dates entry.
- **ANIM223:** Class 10 → October 15 (Midterm Test); Class 19 → November 17 (Assignment 3); Class 19 → November 17 (Assignment 4: Team Presentation Project).
- **ANIM353:** Class 3 → September 21 (The Flightless Bird); Class 5 → September 28 (Horse Walk); Class 7 → October 5 (Horse Trot).

Do the ANIM223 and ANIM353 conversions look right? Once you confirm, I’ll continue.

My response: Yes it looks right

Agent Response:

Thanks. The nine required conversions are confirmed. I’m finishing the full item extraction now, including the third course, then I’ll write the calendar, overlap flags, unscheduled items, and the next-14-days review.

Agent Question 5:

The agent said: The calendar includes all three syllabi, the class meetings, dated assignments and events, two-hour study blocks, overlap flags, and items marked **NEEDS DATE**. You confirmed the AI101 date choices and all nine class-to-date checks.

The main overlap is **November 19**: AI101’s Capstone and Professional Practice are due alongside ANIM223’s Final Test. The week of **November 16–22** has six due items.

- Full calendar and decision log (project-03/outputs/vault-agent-run.md)
- Weekly review for Oct 24–Nov 7 (project-02/outputs/weekly-review.md)

The weekly review is ready for your syllabus and announcement check; I haven’t checked Blackboard or email.

My response: There are no new changes

**Decisions it made that I must defend:** The agent did not make any decisions on its own, anytime there was a conflict, it paused and asked me for my input. 

## Failures and fixes

| What failed                        | What I changed                           | Result                         |
| ---------------------------------- | ---------------------------------------- | ------------------------------ |
| [e.g. agent skipped the tie check] | [e.g. added "stop on ties" to the skill] | [e.g. stopped on the next run] |
|                                    |                                          |                                |



| #   | What the agent decided                                                                                      | Was it right? | Rule or step it followed or broke                                                                                                                                                                                                                                                                                                                                 |
| --- | ----------------------------------------------------------------------------------------------------------- | ------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 1   | Couldn't read the PDFs; stopped and asked for a PDF tool                                                    | Yes           | Rule 4: never guess                                                                                                                                                                                                                                                                                                                                               |
| 2   | The vault agent’s NEEDS DATE list says:<br><br>> **AI101:** No additional items without a clear date found. | No            | AI101 has several undated items, and my earlier runs caught all of them: the study trip (TBD), four extra help sessions (Fridays, TBD), office hours (TBD), the midterm conference, and course evaluations. It also dropped undated items from the other courses, including both midterm conferences, ANIM223’s Friday office hours, and the team Discord weekend |
| 3   | **Voice rule slip:** the file opens with a summary paragraph, not the calendar.                             | No            | voice-profile rule 4 broken                                                                                                                                                                                                                                                                                                                                       |


| What failed                                                                                                                                                 | What I changed                                                                                                                                   | Result                                                                                                                                                                        |
| ----------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Codex agent stress test (run 1): with conflicting AI101 date lists, the agent applied `decision-note.md` on its own and didn't ask me                       | Rewrote hard rule 3: the decision note applies only to AI101's class-date conflict, the agent must say which decision it used, and ask otherwise | Run 2 stopped, showed the conflict (Class 1: 9/15 vs. 9/14), and asked. It held when I said "proceed anyway"                                                                  |
| Project 2 workflow stress test: the run moved all five AI101 graded due dates a day later on its own ("Each one matched exactly, so I did not need to ask") | Added to `02-extract-dated-items.md`: copy due dates exactly, list both and ask if they don't match, and this overrides the decision note        | Run 3 left all five as NEEDS DATE and asked "Which date do you want?" But it credited my answer from an earlier session, not the new line, so I can't prove the fix caused it |
| Project 2 workflow had no step that stopped on graded due dates                                                                                             | Part A: replaced step 2 with `agents/date-extractor.md`, which may not move a graded due date                                                    | Agent run held all five due dates and asked: "Five AI101 due dates held back because they fell on Wednesdays"                                                                 |
| My decision-note rule (2 hours of study before each due date) was never applied: "That is not in `hard-rules.md` or the skill. So I did not add it"         | Made it hard rule 1 in `project-03/vault-agent/hard-rules.md`                                                                                    | Vault agent run added a 2-hour block the day before every due item and listed same-day blocks separately (3 on Wed 11/18)                                                     |
| Fresh-input test: the vault agent couldn't read the PDF syllabi and stopped                                                                                 | Installed poppler (`pdftotext`). Didn't edit the agent, skill, or input                                                                          | It read all three PDFs and built the calendar. All ANIM353 class-number dates match the syllabus (Class 3 = 9/21 through Class 20 = 11/18)                                    |

