# run-comparison.md



## The two runs

|                    | Project 2 run                                        | Agent run                                            |
| ------------------ | ---------------------------------------------------- | ---------------------------------------------------- |
| Saved output       | outputs/p2-run.md                                    | outputs/agent-run.md                                 |
| Input used         | project-02/input/Syllabi/AI101.pdf` and `ANIM223.pdf | `project-02/input/Syllabi/AI101.pdf` and ANIM223.pdf |
| Step file or agent | 02-extract-dated-items.md                            | agents/date-extractor.md                             |

Only step 2 changed. Steps 1, 3, 4, and 5 used the same step files in both runs.


## What changed

**1. The Grading Opportunity Dates for AI101** The Grading Opportunity Dates were different from the Class Dates. The Project 2 run moved them automatically to the class date on its own. However, the agent run put them under NEEDS DATE and waited for my input.

**2. More NEEDS DATE items flagged by agent** - Project 2 run: 77 items, 9 NEEDS DATE (AI101 6, ANIM223 3). - Agent run: 82 items, 11 NEEDS DATE (AI101 7, ANIM223 4). - The agent added both courses' office hours: AI101 "TBD," and ANIM223 "Fridays from 9am to 11 am" with no start or end date. Project 2 left the office hours for both the courses out. 

**3. Item types** - Agent created more meaningful item types than the Project 2 run. - Trip, Help session, Office hours, Event, Graded item. 

**4. Extra help sessions** - The agent sorted AI101 extra help sessions 1, 2, 3, 4. The syllabus lists them 1, 2, 4, 3. 

**5. Overlaps.** Both runs flagged the same two weeks: Nov 16–22 as a heavy week (5 due items across both courses) and Thu 11/19 as a same-day overlap (3 items, both courses).

## Better or worse

My verdict is that the output is better, because it didn't move the grading opportunity dates without asking. It also included the two office hours that my original run from the Project 2 missed. 

I also noticed that the Agent Run gave better names for the items as seen in the table below.

|Item|Project 2 run|Agent run|
|---|---|---|
|Study Trip 1|`class`|`Trip`|
|Extra Help Session 1|`class`|`Help session`|
|Office Hours|not listed|`Office hours`|
|Midterm Conference|`class`|`Event`|
|Professional Practice|`assignment`|`Graded item`|
For the graded opportunity items, I choose the class meeting dates so that I'm not late on my submission.



## What I would change next

**Say how to handle office hours.** - I would like to say how to handle the office hours of my professors for each of the courses. I did not mention how to handle the office hours in my agent, but the agent decided on its own to include them.