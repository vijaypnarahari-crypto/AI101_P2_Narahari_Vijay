# disclosure.md

## What AI contributed

| Date     | What I asked Claude to do                                         | What it produced                                                         | What I kept, changed, or rejected                                                      |
| -------- | ----------------------------------------------------------------- | ------------------------------------------------------------------------ | -------------------------------------------------------------------------------------- |
| 10/23/26 | Explain what to do for the stress test, fix, and audit note steps | Step-by-step instructions and git commands                               | Followed the steps                                                                     |
| 10/23/26 | Find what broke in my P2 stress-test run                          | Pointed to the five moved due dates and the "matched exactly" line       | Kept as my main finding                                                                |
| 10/23/26 | Suggest a fix for step 02                                         | A suggested rule line for `02-extract-dated-items.md`                    | Changed: wrote my own version, added that it overrides decision-note.md                |
| 10/23/26 | Check whether run 2 was fixed by my change                        | Showed run 2 credited my past answer, not a file change                  | Kept: made the real fix and ran a third time                                           |
| 10/23/26 | Explain Part A and pick which step to replace                     | Recommended step 02 and why                                              | Kept step 02                                                                           |
| 10/23/26 | Draft the Part A agent file from step 02                          | Draft date-extractor agent: role, inputs, actions, limits, human check   | Changed the wording to match my exact intent                                           |
| 10/23/26 | Show where the four-line call goes in my start file               | Placement under step 2 in `00-start-here.md`                             | Kept                                                                                   |
| 10/23/26 | Fix the Syllabi / syllabi folder name confusion                   | Steps to keep `Syllabi` and update two step files                        | Kept                                                                                   |
| 10/23/26 | Find the busiest weeks across AI101 and ANIM223                   | Table of due items per week from the ANIM223 PDF                         | Used it to check the agent's step 4 list                                               |
| 10/23/26 | Help write the weekly review                                      | "No changes" draft with four unconfirmed AI101 items                     | Kept after checking announcements myself                                               |
| 10/24/26 | Explain how to build `p2-run.md` from my original outputs         | Commands to combine dated-items, calendar, and overlaps                  | Kept                                                                                   |
| 10/24/26 | Draft the run comparison                                          | "What changed" with quotes from both runs                                | Changed all sections except the two runs.                                              |
| 10/24/26 | Draft my SKILL.md and review it                                   | Draft skill with 8 steps and a complex step; found errors in my versions | Changed: fixed "never decides," all courses, header format, output file name           |
| 10/24/26 | Help write hard rules and voice profile                           | Suggested wording and how to fit my rules in five slots                  | Changed: study-block rule as rule 1, teaching rule as step by step, my own voice lines |
| 10/24/26 | Draft the vault agent AGENTS.md                                   | Identity, how I work, may do, may not do; full paths for Read first      | Changed: [check]. Kept full paths                                                      |
| 10/24/26 | Check my vault agent run against the syllabi                      | Confirmed dates; found it missed AI101's undated items                   | Kept: logged the miss in my testing log                                                |
| 10/24/26 | Fill in my failure table                                          | Table of what failed, what I changed, and the result                     | Added information as needed                                                            |
| 10/24/26 | Draft this AI use log                                             | These two tables                                                         | Kept                                                                                   |
## What I decided

My decision is in the table above
## Tools used

- Claude, Claudian plugin in Obsidian, and Codex




