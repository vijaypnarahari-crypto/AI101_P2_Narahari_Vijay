# Calendar download (.ics): run log, 2026-10-28

**File:** `project-03/outputs/syllabi-calendar.ics`
**Built from:** the calendar-by-week section of `project-03/outputs/vault-agent-run.md` (the 10/24 run: AI101, ANIM223, ANIM353). You picked this one. Nothing re-extracted from the syllabi, except class times (see below).

## What is in the file (98 events)
- 60 classes (20 per course), with times and rooms from each syllabus.
  - AI101: Tue/Thu 5:00 PM to 7:30 PM, SATLAB 123
  - ANIM223: Tue/Thu 8:00 AM to 10:30 AM, MONTGO 309
  - ANIM353: Mon/Wed 5:00 PM to 7:30 PM, MONTGO 321
- 18 due items, all-day, titled `[Course] DUE: exact name`
- 18 two-hour study blocks, the day before each due item (hard-rules.md). All-day on purpose. No start time is set, so you move them. Where several land on one day (Oct 14, Nov 16, Nov 17, Nov 18) each is its own event.
- 2 timed events: ANIM223 extra help (Oct 15, 2 to 4 pm, Room 309) and the Jen Library trip (Nov 7, 10 am to 12 pm)
- Overlap flags sit in the description of the affected due items. Flag only. No ranking.

## Left out
- All NEEDS DATE items (listed at the bottom of `vault-agent-run.md`).
- Rows the 10/24 run doesn't have: ANIM223 launch dates, optional ANIM223 events, AI101 extra help, AI101 trip, midterm conferences, office hours.

## Times
Times have no time zone attached. Your calendar app reads them as local time.

## Flag for you
The 10/24 run puts the ANIM223 reading "Chapters 19 & 20" on Class 16 (Thu 11/5). The ANIM223 syllabus lists it under Class 17 (Tue 11/10). It is in the .ics as the 10/24 run has it. I did not change it.

## Run log
- **Asked:** Create the calendar so I can download it.
- **Chose:** Three courses, from the 10/24 run. **Status:** keep (your choice).
- **Changed:** Created the .ics and this log. Nothing else touched, including `weekly-review.md`.
- **Chapters 19 & 20 date:** **Status:** pending your decision.
