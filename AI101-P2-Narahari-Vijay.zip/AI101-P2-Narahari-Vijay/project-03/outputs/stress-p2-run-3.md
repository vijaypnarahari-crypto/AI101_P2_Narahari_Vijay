---
run: Project 2 workflow, Steps 1 to 5 (project-02/01-collect-syllabi.md)
input: project-02/input/stress-test/AI101-syllabus.md
run-date: 2026-10-23
status: Steps 1 to 5 prepared. The review is yours. Waiting on your answers and checks.
---

# P2 Run 3: Step 1, Collect the syllabi

No calendar yet. Step 1 only collects and checks. You said to follow Step 1 only, so I stopped here.

## Result

**Step 1 is not fully met.** The run does not move to Step 2 until you say "Inputs are ready. Start step 2."

## What I checked

| Check from the step file | Result |
|---|---|
| Input file exists | Yes. `project-02/input/stress-test/AI101-syllabus.md` |
| Only that one input used | Yes. |
| Has a schedule of class meeting dates | Yes. "Class Meeting Dates" lists 20 classes, Tue/Thu, Sep 15 to Nov 19, 2026. |
| Exactly two files, AI101 and ANIM223 | **No.** One file. |
| File is a PDF | **No.** It is a Markdown text copy. |
| Latest version posted | **I can't tell.** The file says "printed 10/4/26". I can't check Blackboard. That's your check. |

## Flags (you decide)

1. **One course only.** Step 1 says two syllabi. The cross-course overlap check later can't run with one.
2. **Markdown, not PDF.** Step 1 says PDF.
3. **Date lists don't match (AI101).** Class Meeting Dates and Schedule of Classes differ by one day on every class. Example: Class 1 is Tue 9/15 in one and Mon 9/14 in the other. I did not pick one. Your decision note covers classes for AI101. At the end of the last session you said to ask each time for the grading dates. Those match the Schedule of Classes, not the meeting dates.
4. **Undated items seen:** study trip, office hours, four extra help sessions, midterm conference, course evaluations ("Weeks 8, 9, and 10"). None has a clear date. I'll ask when we get to dates.
5. **Oddities in the text:** Extra Help rows are numbered 1, 2, 4, 3. Professional Practice weight is "15" with no % sign. Pre-quarter Assignment is due "by the first class meeting".

## Not in your request (flagging)

- Earlier files are in `project-03/outputs/` (`p2-run.md`, `p2-run-2.md`, `p2-stress-test/`). I did not open or reuse them this run.
- `project-02/ai-use-log.md` shows as modified in git from before. I did not touch it. I changed nothing in `project-02/`.

## Next

Tell me: is one course and a Markdown file OK? Then say "Inputs are ready. Start step 2." I won't start Step 2 without it.

## Run log (hard rule 5)

| What you asked | What changed | Keep / change / reject |
|---|---|---|
| Follow `01-collect-syllabi.md` on the stress-test AI101 syllabus only. Save to `project-03/outputs/p2-run-3.md`. Don't change `project-02/`. | Created this file. Nothing in `project-02/` changed. | Waiting on you |
| (my call) Stopped before Step 2 | You didn't say "Start step 2". Input also fails "two PDFs". | Waiting on you |
| (my call) Did not apply the decision note | Dates aren't used until Step 2. | Waiting on you |


---

# Step 2: Extract every dated item

You asked for Step 2 directly. I took that as "Start step 2". Flags 1 and 2 from Step 1 (one course, Markdown file) are still unanswered, so I ran on one course and a Markdown file.

**Counts**
- AI101: 35 items. 21 have a date (20 classes, 1 pre-quarter assignment). 14 are `NEEDS DATE`.
- ANIM223: 0 (not in this run).
- `NEEDS DATE`: 14. That is 5 grading items and 9 other items.

## Table

| Course | Item (exact syllabus wording) | Type | As written | Calendar date | Notes |
|---|---|---|---|---|---|
| AI101 | Class 1: Set Up Your Practice | class | Class 1 | 2026-09-15 (Tue) | Class Meeting Dates #1. Schedule of Classes says 9/14/26 (not used; decision-note). |
| AI101 | Pre-quarter Assignment: Your Agent Brief | assignment | "By the first class meeting" | 2026-09-15 (Tue) | First class meeting = Class 1 in Class Meeting Dates (decision-note). |
| AI101 | Class 2: Make Something | class | Class 2 | 2026-09-17 (Thu) | Class Meeting Dates #2. Schedule of Classes says 9/16/26 (not used; decision-note). |
| AI101 | Class 3: See the Whole Room | class | Class 3 | 2026-09-22 (Tue) | Class Meeting Dates #3. Schedule of Classes says 9/21/26 (not used; decision-note). |
| AI101 | Class 4: Name the Trade | class | Class 4 | 2026-09-24 (Thu) | Class Meeting Dates #4. Schedule of Classes says 9/23/26 (not used; decision-note). |
| AI101 | Class 5: Name the Process | class | Class 5 | 2026-09-29 (Tue) | Class Meeting Dates #5. Schedule of Classes says 9/28/26 (not used; decision-note). |
| AI101 | Class 6: Verify Your Sources | class | Class 6 | 2026-10-01 (Thu) | Class Meeting Dates #6. Schedule of Classes says 9/30/26 (not used; decision-note). |
| AI101 | Class 7: Build a Pipeline | class | Class 7 | 2026-10-06 (Tue) | Class Meeting Dates #7. Schedule of Classes says 10/5/26 (not used; decision-note). |
| AI101 | Class 8: Take Feedback, Iterate | class | Class 8 | 2026-10-08 (Thu) | Class Meeting Dates #8. Schedule of Classes says 10/7/26 (not used; decision-note). |
| AI101 | Class 9: Disclosure and Position | class | Class 9 | 2026-10-13 (Tue) | Class Meeting Dates #9. Schedule of Classes says 10/12/26 (not used; decision-note). |
| AI101 | Class 10: Study Your Field | class | Class 10 | 2026-10-15 (Thu) | Class Meeting Dates #10. Schedule of Classes says 10/14/26 (not used; decision-note). |
| AI101 | Class 11: Build for Your Field | class | Class 11 | 2026-10-20 (Tue) | Class Meeting Dates #11. Schedule of Classes says 10/19/26 (not used; decision-note). |
| AI101 | Class 12: Crit and Revise | class | Class 12 | 2026-10-22 (Thu) | Class Meeting Dates #12. Schedule of Classes says 10/21/26 (not used; decision-note). |
| AI101 | Class 13: Define Your Agent | class | Class 13 | 2026-10-27 (Tue) | Class Meeting Dates #13. Schedule of Classes says 10/26/26 (not used; decision-note). |
| AI101 | Class 14: Assemble the Sources | class | Class 14 | 2026-10-29 (Thu) | Class Meeting Dates #14. Schedule of Classes says 10/28/26 (not used; decision-note). |
| AI101 | Class 15: Build and Test | class | Class 15 | 2026-11-03 (Tue) | Class Meeting Dates #15. Schedule of Classes says 11/2/26 (not used; decision-note). |
| AI101 | Class 16: Find the Failures | class | Class 16 | 2026-11-05 (Thu) | Class Meeting Dates #16. Schedule of Classes says 11/4/26 (not used; decision-note). |
| AI101 | Class 17: Revise | class | Class 17 | 2026-11-10 (Tue) | Class Meeting Dates #17. Schedule of Classes says 11/9/26 (not used; decision-note). |
| AI101 | Class 18: Confirm the Difference | class | Class 18 | 2026-11-12 (Thu) | Class Meeting Dates #18. Schedule of Classes says 11/11/26 (not used; decision-note). |
| AI101 | Class 19: Demo and Defend | class | Class 19 | 2026-11-17 (Tue) | Class Meeting Dates #19. Schedule of Classes says 11/16/26 (not used; decision-note). |
| AI101 | Class 20: Reflect and Carry Forward | class | Class 20 | 2026-11-19 (Thu) | Class Meeting Dates #20. Schedule of Classes says 11/18/26 (not used; decision-note). |
| AI101 | Project 1: Make, Then Compare | project | Grading Opportunities #1, 9/23/26 | NEEDS DATE | Syllabus says 9/23/26, same as Schedule of Classes Class 4. Class 4 meeting date is 2026-09-24 (Thu). Not moved. You said to ask each time. Weight 15%. Type is my reading. |
| AI101 | Project 2: Small Orchestration | project | Grading Opportunities #2, 10/7/26 | NEEDS DATE | Syllabus says 10/7/26, same as Schedule of Classes Class 8. Class 8 meeting date is 2026-10-08 (Thu). Not moved. You said to ask each time. Weight 20%. Type is my reading. |
| AI101 | Project 3: Your Field, With AI | project | Grading Opportunities #3, 10/21/26 | NEEDS DATE | Syllabus says 10/21/26, same as Schedule of Classes Class 12. Class 12 meeting date is 2026-10-22 (Thu). Not moved. You said to ask each time. Weight 20%. Type is my reading. |
| AI101 | Capstone: Your Own Agent | project | Grading Opportunities #4, 11/18/26 | NEEDS DATE | Syllabus says 11/18/26, same as Schedule of Classes Class 20. Class 20 meeting date is 2026-11-19 (Thu). Not moved. You said to ask each time. Weight 30%. Type is my reading. |
| AI101 | Professional Practice | assignment | Grading Opportunities #5, 11/18/26 | NEEDS DATE | Syllabus says 11/18/26, same as Schedule of Classes Class 20. Class 20 meeting date is 2026-11-19 (Thu). Not moved. You said to ask each time. Weight 15 (no % sign in syllabus). Type is my reading. |
| AI101 | Office Hours | other | "Office Hours: TBD, Zoom: ..." | NEEDS DATE | No day or time. |
| AI101 | Study (Field) Trip 1 | other | "TBD and will announce on BB" | NEEDS DATE | Date TBD. |
| AI101 | Extra Help Session 1 | other | "Extra Help Session are on Fridays, Date and Time will be announced on BB" | NEEDS DATE | Fridays only. No date. |
| AI101 | Extra Help Session 2 | other | same wording as above | NEEDS DATE | Fridays only. No date. |
| AI101 | Extra Help Session 4 | other | same wording as above | NEEDS DATE | Fridays only. No date. Listed before 3. |
| AI101 | Extra Help Session 3 | other | same wording as above | NEEDS DATE | Fridays only. No date. Listed after 4. |
| AI101 | Midterm Conference(s) | other | "scheduled outside of class time with the professor" | NEEDS DATE | No date or week. |
| AI101 | Course Evaluations | other | "Weeks 8, 9, and 10 through MySCAD" | NEEDS DATE | Syllabus lists no dates for weeks. |
| AI101 | GitHub account setup | other | "set up in class, Week 2" | NEEDS DATE | Syllabus lists no dates for weeks. Week 2 holds two classes. |

## Which date decision I used (hard rule 3)

The two AI101 date lists don't match, on all 20 classes. So I used your `decision-note.md` for classes: **Class Meeting Dates, not the Schedule of Classes.** AI101 only.

I did **not** use it for the 5 grading dates. You said to ask each time. So they are `NEEDS DATE`.

## How I got the dates (hard rule 1)

- "Class N" = number N in Class Meeting Dates. Class 5 is Tuesday, September 29.
- "By the first class meeting" = Class 1. That is Tuesday, September 15.

## I need you (hard rule 3)

I did not pick any of these.

1. **Grading dates.** Which date do you want?

| Item | Syllabus says | Class meeting date for that class |
|---|---|---|
| Project 1: Make, Then Compare | 9/23/26 | Thu 9/24 |
| Project 2: Small Orchestration | 10/7/26 | Thu 10/8 |
| Project 3: Your Field, With AI | 10/21/26 | Thu 10/22 |
| Capstone: Your Own Agent | 11/18/26 | Thu 11/19 |
| Professional Practice | 11/18/26 | Thu 11/19 |

2. **Office hours, study trip, extra help (four), midterm conference.** No dates. Do you have dates, or do they stay unscheduled?
3. **Course Evaluations ("Weeks 8, 9, and 10").** The syllabus gives no dates for weeks.
4. **GitHub setup ("in class, Week 2").** Class 3 (9/22) or Class 4 (9/24)?

## Things you didn't ask for (flagging)

- The 9 non-grading `NEEDS DATE` rows are not classes, readings, assignments, projects, or tests. I typed them `other`.
- Types for grading items are my reading. The syllabus doesn't say.
- Not extracted: in-class tasks ("start your AI Use Log", "publish your folder to GitHub"). They have no date apart from their class. No readings, tests, or "no class" days are in this syllabus. ELO links have no dates.
- Oddities copied as written: Extra Help rows go 1, 2, 4, 3. Professional Practice weight is "15".

## Human check (yours)

Pick three AI101 items. Look up the class number in Class Meeting Dates. Tell me if they match. If any is wrong, tell me which, and I rerun Step 2. I won't start Step 3 until you say so.

## Run log, Step 2 (hard rule 5)

| What you asked | What changed | Keep / change / reject |
|---|---|---|
| Follow `02-extract-dated-items.md`. Final result goes in `project-03/outputs/p2-run-3.md`. | Added this section. Nothing in `project-02/` changed. | Waiting on you |
| (my call) Treated your request as "Start step 2" | Step 1 flags still open | Waiting on you |
| (my call) Used decision-note for 20 classes and the pre-quarter assignment | See table | Waiting on you |
| (my call) Did not move the 5 grading dates, made them `NEEDS DATE` | Follows your "ask each time" answer | Waiting on you |


---

# Step 3: Add events to the calendar

You asked for Step 3 directly. I took that as the go-ahead. Your Step 2 checks and answers are still open.

## Calendar

AI101 meets Tue / Thu, 5:00 PM - 7:30 PM, SATLAB 123 (from the syllabus header). Weeks run Monday to Sunday.

### Week of Sep 14–Sep 20

| Date | Day | Course | Event |
|---|---|---|---|
| 9/15/2026 | Tue | AI101 | [AI101] Class 1: Set Up Your Practice |
| 9/15/2026 | Tue | AI101 | [AI101] Assignment: Pre-quarter Assignment: Your Agent Brief |
| 9/17/2026 | Thu | AI101 | [AI101] Class 2: Make Something |

### Week of Sep 21–Sep 27

| Date | Day | Course | Event |
|---|---|---|---|
| 9/22/2026 | Tue | AI101 | [AI101] Class 3: See the Whole Room |
| 9/24/2026 | Thu | AI101 | [AI101] Class 4: Name the Trade |

### Week of Sep 28–Oct 4

| Date | Day | Course | Event |
|---|---|---|---|
| 9/29/2026 | Tue | AI101 | [AI101] Class 5: Name the Process |
| 10/1/2026 | Thu | AI101 | [AI101] Class 6: Verify Your Sources |

### Week of Oct 5–Oct 11

| Date | Day | Course | Event |
|---|---|---|---|
| 10/6/2026 | Tue | AI101 | [AI101] Class 7: Build a Pipeline |
| 10/8/2026 | Thu | AI101 | [AI101] Class 8: Take Feedback, Iterate |

### Week of Oct 12–Oct 18

| Date | Day | Course | Event |
|---|---|---|---|
| 10/13/2026 | Tue | AI101 | [AI101] Class 9: Disclosure and Position |
| 10/15/2026 | Thu | AI101 | [AI101] Class 10: Study Your Field |

### Week of Oct 19–Oct 25

| Date | Day | Course | Event |
|---|---|---|---|
| 10/20/2026 | Tue | AI101 | [AI101] Class 11: Build for Your Field |
| 10/22/2026 | Thu | AI101 | [AI101] Class 12: Crit and Revise |

### Week of Oct 26–Nov 1

| Date | Day | Course | Event |
|---|---|---|---|
| 10/27/2026 | Tue | AI101 | [AI101] Class 13: Define Your Agent |
| 10/29/2026 | Thu | AI101 | [AI101] Class 14: Assemble the Sources |

### Week of Nov 2–Nov 8

| Date | Day | Course | Event |
|---|---|---|---|
| 11/3/2026 | Tue | AI101 | [AI101] Class 15: Build and Test |
| 11/5/2026 | Thu | AI101 | [AI101] Class 16: Find the Failures |

### Week of Nov 9–Nov 15

| Date | Day | Course | Event |
|---|---|---|---|
| 11/10/2026 | Tue | AI101 | [AI101] Class 17: Revise |
| 11/12/2026 | Thu | AI101 | [AI101] Class 18: Confirm the Difference |

### Week of Nov 16–Nov 22

| Date | Day | Course | Event |
|---|---|---|---|
| 11/17/2026 | Tue | AI101 | [AI101] Class 19: Demo and Defend |
| 11/19/2026 | Thu | AI101 | [AI101] Class 20: Reflect and Carry Forward |

### Not yet scheduled

No clear date in the syllabus, or waiting on your answer. I did not pick one.

| Item | As written | Why |
|---|---|---|
| Project 1: Make, Then Compare | Grading Opportunities #1, 9/23/26 | Syllabus says 9/23/26, same as Schedule of Classes Class 4. Class 4 meeting date is 2026-09-24 (Thu). Not moved. You said to ask each time. Weight 15%. Type is my reading. |
| Project 2: Small Orchestration | Grading Opportunities #2, 10/7/26 | Syllabus says 10/7/26, same as Schedule of Classes Class 8. Class 8 meeting date is 2026-10-08 (Thu). Not moved. You said to ask each time. Weight 20%. Type is my reading. |
| Project 3: Your Field, With AI | Grading Opportunities #3, 10/21/26 | Syllabus says 10/21/26, same as Schedule of Classes Class 12. Class 12 meeting date is 2026-10-22 (Thu). Not moved. You said to ask each time. Weight 20%. Type is my reading. |
| Capstone: Your Own Agent | Grading Opportunities #4, 11/18/26 | Syllabus says 11/18/26, same as Schedule of Classes Class 20. Class 20 meeting date is 2026-11-19 (Thu). Not moved. You said to ask each time. Weight 30%. Type is my reading. |
| Professional Practice | Grading Opportunities #5, 11/18/26 | Syllabus says 11/18/26, same as Schedule of Classes Class 20. Class 20 meeting date is 2026-11-19 (Thu). Not moved. You said to ask each time. Weight 15 (no % sign in syllabus). Type is my reading. |
| Office Hours | "Office Hours: TBD, Zoom: ..." | No day or time. |
| Study (Field) Trip 1 | "TBD and will announce on BB" | Date TBD. |
| Extra Help Session 1 | "Extra Help Session are on Fridays, Date and Time will be announced on BB" | Fridays only. No date. |
| Extra Help Session 2 | same wording as above | Fridays only. No date. |
| Extra Help Session 4 | same wording as above | Fridays only. No date. Listed before 3. |
| Extra Help Session 3 | same wording as above | Fridays only. No date. Listed after 4. |
| Midterm Conference(s) | "scheduled outside of class time with the professor" | No date or week. |
| Course Evaluations | "Weeks 8, 9, and 10 through MySCAD" | Syllabus lists no dates for weeks. |
| GitHub account setup | "set up in class, Week 2" | Syllabus lists no dates for weeks. Week 2 holds two classes. |

**Counts:** 21 events added (20 classes, 1 due date). 0 changed (first build). 14 in Not yet scheduled.

## Things to know

- **Only 1 due date is on the calendar.** The 5 grading items (Projects 1-3, Capstone, Professional Practice) are in Not yet scheduled until you answer the grading date question in Step 2.
- **Office hours:** syllabus says "TBD", so no weekly office hours event.
- **No class days:** the syllabus lists none.
- **Class time:** stated once above, not on each event.
- Not added: study hours, priorities, late flags.

## Human check (yours)

Dated rows in the Step 2 table: 21. Events above: 21. They match on my side. Tell me if they do not match on yours. I won't start Step 4 until you say so.

## Run log, Step 3 (hard rule 5)

| What you asked | What changed | Keep / change / reject |
|---|---|---|
| Follow `03-add-events.md` | Added this section. Nothing in `project-02/` changed. | Waiting on you |
| (my call) Treated your request as Step 2 approved | Step 2 checks still open | Waiting on you |
| (my call) Left the 5 grading items off the calendar | They are NEEDS DATE | Waiting on you |


---

# Step 4: Check for overlapping due dates

You asked for Step 4 directly. I took that as the go-ahead. Step 3 count check is still open.

**Overlaps found: 0.** This check is weak. Read the notes below.

| Dates | Items (course + exact name) | Why it is flagged |
|---|---|---|
| none | none | none |

## What I checked

1. **Same day, AI101 and ANIM223:** Can't run. ANIM223 is not in this run.
2. **Weeks with 3 or more due items:** None on the calendar. It has 1 due item: the Pre-quarter Assignment (week of Sep 14).
3. **Tests in both courses:** None. No tests in this syllabus, and no second course.

## Why this is weak

The 5 grading items are not on the calendar. They wait on your date answer from Step 2. So the check only saw 1 due item. I can't call a week light when 5 due items are missing.

I did not pick a grading date. But I can tell you what holds under either candidate date (the syllabus date or the class meeting date for that class):

| Item | Syllabus date | Class meeting date | Week it lands in (both options) |
|---|---|---|---|
| Project 1 | 9/23 | 9/24 | Sep 21–Sep 27 |
| Project 2 | 10/7 | 10/8 | Oct 5–Oct 11 |
| Project 3 | 10/21 | 10/22 | Oct 19–Oct 25 |
| Capstone | 11/18 | 11/19 | Nov 16–Nov 22 |
| Professional Practice | 11/18 | 11/19 | Nov 16–Nov 22 |

- No week reaches 3 due items under either option. The most is 2, in the week of Nov 16.
- Capstone and Professional Practice share one date under either option (same day, same course). That's not an overlap by this step's rule, which flags two courses. I did not rank them or suggest moving either.

Rerun Step 4 after you pick the grading dates.

## Human check (yours)

Scan the busiest weeks yourself. If one is missing from my list, tell me and I rerun Step 4. I won't start Step 5 until you say so.

## Run log, Step 4 (hard rule 5)

| What you asked | What changed | Keep / change / reject |
|---|---|---|
| Follow `04-check-overlaps.md` | Added this section. Nothing in `project-02/` changed. | Waiting on you |
| (my call) Counted 0 overlaps. Showed both candidate grading dates, picked neither | See table | Waiting on you |
| (my call) Treated your request as Step 3 approved | Step 3 count check still open | Waiting on you |


---

# Step 5: Weekly review (model prep only)

Today is Friday 10/23. Step 5 normally starts on Sunday evening. You asked for it now, so I ran it now.

## Next 14 days: Fri 10/23 to Thu 11/5

| Date | Day | Course | Event |
|---|---|---|---|
| 10/27 | Tue | AI101 | Class 13: Define Your Agent |
| 10/29 | Thu | AI101 | Class 14: Assemble the Sources |
| 11/3 | Tue | AI101 | Class 15: Build and Test |
| 11/5 | Thu | AI101 | Class 16: Find the Failures |

**4 events.** No due items are on the calendar in this window.

## Overlaps in this window

None. Step 4 found 0.

## Could land in this window, but I can't place them

- **Grading items.** Their dates wait on your Step 2 answer. Every candidate date (9/23, 9/24, 10/7, 10/8, 10/21, 10/22, 11/18, 11/19) is outside this window. So they do not change this list either way.
- **Undated items.** Extra help sessions are on Fridays (10/30 is in the window; 11/6 is just outside). Also the study trip, midterm conference, office hours, and course evaluations. Check Blackboard.

## Your part (I did not do these)

1. Check each date above against the syllabus and the past week's announcements.
2. Write corrections in `weekly-review.md` under today's date: `Course | Item | Old date | New date | Source`. Or write "No changes".
3. Plan for overlaps: none in this window.
4. Corrections go back to Step 3.

Nothing here counts as confirmed until you check it.

## Things to know

- I did not create `weekly-review.md`. It is your file, and `project-02/` is off limits in this run.
- Only AI101 is here. Step 5 also reads ANIM223.

## Run log, Step 5 (hard rule 5)

| What you asked | What changed | Keep / change / reject |
|---|---|---|
| Follow `05-review-weekly.md` | Added this section. Nothing in `project-02/` changed. No `weekly-review.md` written. | Waiting on you |
| (my call) Window = today through 11/5 | 14 days from today | Waiting on you |
