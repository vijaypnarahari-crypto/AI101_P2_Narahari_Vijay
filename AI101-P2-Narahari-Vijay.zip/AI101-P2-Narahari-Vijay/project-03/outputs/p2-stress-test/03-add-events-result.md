---
run: Project 2 workflow, Step 3 only (project-02/03-add-events.md)
input: project-03/outputs/p2-stress-test/dated-items.md
run-date: 2026-10-23
status: Step 3 done. Waiting on your count check. Not starting step 4.
---

# Step 3 report

Calendar: `calendar.md` (same folder).

**Counts**
- Events added: 26 (20 classes, 6 due dates)
- Dated rows in `dated-items.md`: 26
- Not yet scheduled: 9
- Changed: 0 (first build, no step 5 corrections)

## Things to know

- **Titles.** Classes: `[AI101] Class N: name`. Due dates: `[AI101] Type: exact item name`. The 6 due dates are the pre-quarter assignment, Projects 1-3, Capstone, and Professional Practice.
- **Weekly class time.** The syllabus says Tue/Thu 5:00-7:30 PM, SATLAB 123. I put it in a line above the tables. I did not add it to each event, since the columns are fixed.
- **Office hours.** The syllabus says "TBD". So no weekly office hours event. They sit in Not yet scheduled.
- **No class days.** The syllabus lists none, so none were added.
- **Step 2 approval.** The step starts when Step 2 is approved. You asked for Step 3 directly. I took that as the go-ahead. Your three-item date check from Step 2 is still open.
- **Not added:** NEEDS DATE items, study hours, priorities, late flags.

## Human check (yours)

Count dated rows in `dated-items.md` (26). Count events in `calendar.md` (26). They match on my side. Tell me if they don't match on yours.

## Run log (hard rule 5)

| What you asked | What changed | Keep / change / reject |
|---|---|---|
| Follow `03-add-events.md` | Created `calendar.md` and this report. Nothing in `project-02/` changed. | Waiting on you |
| (my call) Proceeded without explicit Step 2 approval | Step 2 human check still open | Waiting on you |
| (my call) Class time stated once in a header line | Not added per event | Waiting on you |
