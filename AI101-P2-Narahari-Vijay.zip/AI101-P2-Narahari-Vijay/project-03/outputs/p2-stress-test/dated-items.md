---
run: Project 2 workflow, Step 2 (project-02/02-extract-dated-items.md)
input: project-02/input/stress-test/AI101-syllabus.md
courses: AI101 only
run-date: 2026-10-23
---

# Dated items: AI101 stress test

| Course | Item (exact syllabus wording) | Type | As written | Calendar date | Notes |
|---|---|---|---|---|---|
| AI101 | Class 1: Set Up Your Practice | class | Class 1 | 2026-09-15 (Tue) | Class Meeting Dates #1. Schedule of Classes says 9/14/26 (not used; decision-note). Row also opens a unit in the Schedule. |
| AI101 | Pre-quarter Assignment: Your Agent Brief | assignment | "By the first class meeting" | 2026-09-15 (Tue) | Relative date: first class meeting = Class 1 in Class Meeting Dates. |
| AI101 | Class 2: Make Something | class | Class 2 | 2026-09-17 (Thu) | Class Meeting Dates #2. Schedule of Classes says 9/16/26 (not used; decision-note). |
| AI101 | Class 3: See the Whole Room | class | Class 3 | 2026-09-22 (Tue) | Class Meeting Dates #3. Schedule of Classes says 9/21/26 (not used; decision-note). |
| AI101 | Class 4: Name the Trade | class | Class 4 | 2026-09-24 (Thu) | Class Meeting Dates #4. Schedule of Classes says 9/23/26 (not used; decision-note). |
| AI101 | Project 1: Make, Then Compare | project | Grading Opportunities #1, 9/23/26 | 2026-09-24 (Thu) | Grading date 9/23/26 equals Schedule of Classes date for Class 4 exactly, so moved to Class 4 meeting date (decision-note). Weight 15%. Type is my reading. |
| AI101 | Class 5: Name the Process | class | Class 5 | 2026-09-29 (Tue) | Class Meeting Dates #5. Schedule of Classes says 9/28/26 (not used; decision-note). Row also opens a unit in the Schedule. |
| AI101 | Class 6: Verify Your Sources | class | Class 6 | 2026-10-01 (Thu) | Class Meeting Dates #6. Schedule of Classes says 9/30/26 (not used; decision-note). |
| AI101 | Class 7: Build a Pipeline | class | Class 7 | 2026-10-06 (Tue) | Class Meeting Dates #7. Schedule of Classes says 10/5/26 (not used; decision-note). |
| AI101 | Class 8: Take Feedback, Iterate | class | Class 8 | 2026-10-08 (Thu) | Class Meeting Dates #8. Schedule of Classes says 10/7/26 (not used; decision-note). |
| AI101 | Project 2: Small Orchestration | project | Grading Opportunities #2, 10/7/26 | 2026-10-08 (Thu) | Grading date 10/7/26 equals Schedule of Classes date for Class 8 exactly, so moved to Class 8 meeting date (decision-note). Weight 20%. Type is my reading. |
| AI101 | Class 9: Disclosure and Position | class | Class 9 | 2026-10-13 (Tue) | Class Meeting Dates #9. Schedule of Classes says 10/12/26 (not used; decision-note). Row also opens a unit in the Schedule. |
| AI101 | Class 10: Study Your Field | class | Class 10 | 2026-10-15 (Thu) | Class Meeting Dates #10. Schedule of Classes says 10/14/26 (not used; decision-note). |
| AI101 | Class 11: Build for Your Field | class | Class 11 | 2026-10-20 (Tue) | Class Meeting Dates #11. Schedule of Classes says 10/19/26 (not used; decision-note). |
| AI101 | Class 12: Crit and Revise | class | Class 12 | 2026-10-22 (Thu) | Class Meeting Dates #12. Schedule of Classes says 10/21/26 (not used; decision-note). |
| AI101 | Project 3: Your Field, With AI | project | Grading Opportunities #3, 10/21/26 | 2026-10-22 (Thu) | Grading date 10/21/26 equals Schedule of Classes date for Class 12 exactly, so moved to Class 12 meeting date (decision-note). Weight 20%. Type is my reading. |
| AI101 | Class 13: Define Your Agent | class | Class 13 | 2026-10-27 (Tue) | Class Meeting Dates #13. Schedule of Classes says 10/26/26 (not used; decision-note). Row also opens a unit in the Schedule. |
| AI101 | Class 14: Assemble the Sources | class | Class 14 | 2026-10-29 (Thu) | Class Meeting Dates #14. Schedule of Classes says 10/28/26 (not used; decision-note). |
| AI101 | Class 15: Build and Test | class | Class 15 | 2026-11-03 (Tue) | Class Meeting Dates #15. Schedule of Classes says 11/2/26 (not used; decision-note). |
| AI101 | Class 16: Find the Failures | class | Class 16 | 2026-11-05 (Thu) | Class Meeting Dates #16. Schedule of Classes says 11/4/26 (not used; decision-note). |
| AI101 | Class 17: Revise | class | Class 17 | 2026-11-10 (Tue) | Class Meeting Dates #17. Schedule of Classes says 11/9/26 (not used; decision-note). |
| AI101 | Class 18: Confirm the Difference | class | Class 18 | 2026-11-12 (Thu) | Class Meeting Dates #18. Schedule of Classes says 11/11/26 (not used; decision-note). |
| AI101 | Class 19: Demo and Defend | class | Class 19 | 2026-11-17 (Tue) | Class Meeting Dates #19. Schedule of Classes says 11/16/26 (not used; decision-note). |
| AI101 | Class 20: Reflect and Carry Forward | class | Class 20 | 2026-11-19 (Thu) | Class Meeting Dates #20. Schedule of Classes says 11/18/26 (not used; decision-note). |
| AI101 | Capstone: Your Own Agent | project | Grading Opportunities #4, 11/18/26 | 2026-11-19 (Thu) | Grading date 11/18/26 equals Schedule of Classes date for Class 20 exactly, so moved to Class 20 meeting date (decision-note). Weight 30%. Type is my reading. |
| AI101 | Professional Practice | assignment | Grading Opportunities #5, 11/18/26 | 2026-11-19 (Thu) | Grading date 11/18/26 equals Schedule of Classes date for Class 20 exactly, so moved to Class 20 meeting date (decision-note). Weight 15 (no % sign in syllabus). Type is my reading. |
| AI101 | Office Hours | other | "Office Hours: TBD, Zoom: ..." | NEEDS DATE | No day or time in syllabus. |
| AI101 | Study (Field) Trip 1 | other | "TBD and will announce on BB" (Study Trip row 1) | NEEDS DATE | Date TBD. |
| AI101 | Extra Help Session 1 | other | "Extra Help Session are on Fridays, Date and Time will be announced on BB" | NEEDS DATE | Fridays only. No date. |
| AI101 | Extra Help Session 2 | other | same wording as above | NEEDS DATE | Fridays only. No date. |
| AI101 | Extra Help Session 4 | other | same wording as above | NEEDS DATE | Fridays only. No date. Listed before 3 in syllabus. |
| AI101 | Extra Help Session 3 | other | same wording as above | NEEDS DATE | Fridays only. No date. Listed after 4 in syllabus. |
| AI101 | Midterm Conference(s) | other | "scheduled outside of class time with the professor" | NEEDS DATE | No date or week. |
| AI101 | Course Evaluations | other | "Weeks 8, 9, and 10 through MySCAD" | NEEDS DATE | Syllabus lists no dates for weeks, so Weeks 8-10 have no date to match. |
| AI101 | GitHub account setup | other | "set up in class, Week 2" | NEEDS DATE | Syllabus lists no dates for weeks. Week 2 would also hold two classes. |

**Counts:** AI101 dated: 26. AI101 NEEDS DATE: 9. ANIM223: 0 (not in this run).
