---
run: Project 2 workflow, Step 3 (project-02/03-add-events.md)
input: project-03/outputs/p2-stress-test/dated-items.md
courses: AI101 only
run-date: 2026-10-23
---

# Calendar: AI101 stress test

AI101 meets Tue / Thu, 5:00 PM - 7:30 PM, SATLAB 123 (from the syllabus header). Weeks run Monday to Sunday.

Fixed events (classes) and due dates are both below, in date order.

## Week of Sep 14–Sep 20

| Date | Day | Course | Event |
|---|---|---|---|
| 9/15/2026 | Tue | AI101 | [AI101] Class 1: Set Up Your Practice |
| 9/15/2026 | Tue | AI101 | [AI101] Assignment: Pre-quarter Assignment: Your Agent Brief |
| 9/17/2026 | Thu | AI101 | [AI101] Class 2: Make Something |

## Week of Sep 21–Sep 27

| Date | Day | Course | Event |
|---|---|---|---|
| 9/22/2026 | Tue | AI101 | [AI101] Class 3: See the Whole Room |
| 9/24/2026 | Thu | AI101 | [AI101] Class 4: Name the Trade |
| 9/24/2026 | Thu | AI101 | [AI101] Project: Project 1: Make, Then Compare |

## Week of Sep 28–Oct 4

| Date | Day | Course | Event |
|---|---|---|---|
| 9/29/2026 | Tue | AI101 | [AI101] Class 5: Name the Process |
| 10/1/2026 | Thu | AI101 | [AI101] Class 6: Verify Your Sources |

## Week of Oct 5–Oct 11

| Date | Day | Course | Event |
|---|---|---|---|
| 10/6/2026 | Tue | AI101 | [AI101] Class 7: Build a Pipeline |
| 10/8/2026 | Thu | AI101 | [AI101] Class 8: Take Feedback, Iterate |
| 10/8/2026 | Thu | AI101 | [AI101] Project: Project 2: Small Orchestration |

## Week of Oct 12–Oct 18

| Date | Day | Course | Event |
|---|---|---|---|
| 10/13/2026 | Tue | AI101 | [AI101] Class 9: Disclosure and Position |
| 10/15/2026 | Thu | AI101 | [AI101] Class 10: Study Your Field |

## Week of Oct 19–Oct 25

| Date | Day | Course | Event |
|---|---|---|---|
| 10/20/2026 | Tue | AI101 | [AI101] Class 11: Build for Your Field |
| 10/22/2026 | Thu | AI101 | [AI101] Class 12: Crit and Revise |
| 10/22/2026 | Thu | AI101 | [AI101] Project: Project 3: Your Field, With AI |

## Week of Oct 26–Nov 1

| Date | Day | Course | Event |
|---|---|---|---|
| 10/27/2026 | Tue | AI101 | [AI101] Class 13: Define Your Agent |
| 10/29/2026 | Thu | AI101 | [AI101] Class 14: Assemble the Sources |

## Week of Nov 2–Nov 8

| Date | Day | Course | Event |
|---|---|---|---|
| 11/3/2026 | Tue | AI101 | [AI101] Class 15: Build and Test |
| 11/5/2026 | Thu | AI101 | [AI101] Class 16: Find the Failures |

## Week of Nov 9–Nov 15

| Date | Day | Course | Event |
|---|---|---|---|
| 11/10/2026 | Tue | AI101 | [AI101] Class 17: Revise |
| 11/12/2026 | Thu | AI101 | [AI101] Class 18: Confirm the Difference |

## Week of Nov 16–Nov 22

| Date | Day | Course | Event |
|---|---|---|---|
| 11/17/2026 | Tue | AI101 | [AI101] Class 19: Demo and Defend |
| 11/19/2026 | Thu | AI101 | [AI101] Class 20: Reflect and Carry Forward |
| 11/19/2026 | Thu | AI101 | [AI101] Assignment: Professional Practice |
| 11/19/2026 | Thu | AI101 | [AI101] Project: Capstone: Your Own Agent |

## Not yet scheduled

These have no clear date in the syllabus. I did not pick one.

| Item | As written | Why |
|---|---|---|
| Office Hours | "Office Hours: TBD, Zoom: ..." | No day or time in syllabus. |
| Study (Field) Trip 1 | "TBD and will announce on BB" (Study Trip row 1) | Date TBD. |
| Extra Help Session 1 | "Extra Help Session are on Fridays, Date and Time will be announced on BB" | Fridays only. No date. |
| Extra Help Session 2 | same wording as above | Fridays only. No date. |
| Extra Help Session 4 | same wording as above | Fridays only. No date. Listed before 3 in syllabus. |
| Extra Help Session 3 | same wording as above | Fridays only. No date. Listed after 4 in syllabus. |
| Midterm Conference(s) | "scheduled outside of class time with the professor" | No date or week. |
| Course Evaluations | "Weeks 8, 9, and 10 through MySCAD" | Syllabus lists no dates for weeks, so Weeks 8-10 have no date to match. |
| GitHub account setup | "set up in class, Week 2" | Syllabus lists no dates for weeks. Week 2 would also hold two classes. |

**Counts:** 26 events on the calendar. 9 in Not yet scheduled.
