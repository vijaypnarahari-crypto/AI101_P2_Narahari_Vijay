---
run: Project 2 workflow, Step 4 (project-02/04-check-overlaps.md)
input: project-03/outputs/p2-stress-test/calendar.md
courses: AI101 only
run-date: 2026-10-23
---

# Overlaps: AI101 stress test

**Overlaps found: 0.**

| Dates | Items (course + exact name) | Why it is flagged |
|---|---|---|
| none | none | none |

## What I checked

1. **Same day, AI101 and ANIM223:** Can't run. ANIM223 is not in this run. Zero cross-course matches because there is only one course.
2. **Weeks with 3 or more due items:** None. Most due items in one week is 2 (week of Nov 16). All other weeks with due items have 1.
3. **Tests in both courses:** None. There are no tests in this syllabus, and no second course.

Due items per week (assignments, projects, tests only):

| Week | Due items |
|---|---|
| Sep 14–Sep 20 | 1 |
| Sep 21–Sep 27 | 1 |
| Oct 5–Oct 11 | 1 |
| Oct 19–Oct 25 | 1 |
| Nov 16–Nov 22 | 2 |
| All other weeks | 0 |

## Not an overlap by the step's rules, but you should see it

Two AI101 items are due the same day, Thu 11/19: Professional Practice and Capstone: Your Own Agent. The step only flags same-day items across two courses, so I did not count them. I did not rank them and did not suggest moving either one. That's your call.

## Run log (hard rule 5)

| What you asked | What changed | Keep / change / reject |
|---|---|---|
| Follow `04-check-overlaps.md` | Created this file. Nothing in `project-02/` changed. | Waiting on you |
| (my call) Counted 0 overlaps. Mentioned the 11/19 same-day pair in a note, not in the table | See above | Waiting on you |
| (my call) Proceeded without a "Step 3 approved" from you | Step 3 count check still open | Waiting on you |
