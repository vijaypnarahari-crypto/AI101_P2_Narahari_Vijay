# prd.md

**Goal:** When Brian opens the page, it shows the title “Count With Me” and a random number of cars (1 to 20). He counts them and clicks on one of three number choices. If he's right, he sees confetti, "Good job!", and +1 point. If he's wrong, he sees "Let's count again!" and his points stay the same. 

**User:** Brian, a Pre-K student who is learning numbers and loves cars, wants to practice counting cars up to 20. 

**Features:**
1. The user can count a random group of 1 to 20 cars on screen.
2. The user can pick an answer from three number buttons (one correct, two incorrect ones within 3 of the right answer, like 11 and 13 for 12). All three numbers are always between 1 and 20.
3. The user can earn a point for each correct answer, a gold medal for every 5 points, and try the same question again after a wrong one.

**What happens:**
- When Brian opens the page, the game shows a random number of cars (1 to 20) in neat rows of five, with three number buttons below. The two wrong choices are always close to the right answer, so he has to count to tell them apart.
- When Brian clicks on the correct number, confetti falls, "Good job!" appears, his score goes up by 1, and a new set of cars appears.
- When Brian clicks on a wrong number, "Let's count again!" appears, his score stays the same, and the same cars and the same three choices stay on screen so he can try again.
- When Brian reaches every 5th correct answer, a big gold medal appears with "You earned a gold medal!" and moves into the next spot on the medal board, which has 2 rows of 5 under the score. After all 10 medals (50 correct answers), the game celebrates with confetti, and shows "Yay! You Are A Math Star!", and the score and medal board reset to 0.

**Look and feel:** Simple, bright, colorful: sunny yellow, sky blue, and grass green on a soft cream background. Big rounded numbers and large buttons. One question at a time, the title “Count With Me” appears at the top centered to the page, with the score at the top right of the screen and the medal board (2 rows of 5) under it. The cars in the middle centered to the page, and the three number buttons at the bottom centered to the page. No scrolling. 

**Out of scope:** Numbers above 20, timers, subtracting points for wrong answers, the word "wrong," red X's, typing answers, pictures other than cars, sounds, saved score, names or accounts, menus. 

**Done when:**
1. Open the page and play ten rounds. "Count With Me" is at the top center, the score is at the top right, the page never needs scrolling, and every round shows 20 or fewer cars and exactly three number choices, with one correct and the other two within 3 of it.
2. Click on the correct answer. Confetti and "Good job!" appear, the score goes up by exactly 1, and a new set of cars appears. After 5 correct answers, a gold medal appears and moves into the first spot on the medal board.
3. Click on a wrong answer. "Let's count again!" appears, the score stays the same, the same cars and choices stay on screen, and the word "wrong" or a red X never shows.
