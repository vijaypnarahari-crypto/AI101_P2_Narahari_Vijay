# plan.md

1. **Option:** game
2. **User:** Brian, a Pre-K student, is learning numbers and wants to practice counting an object he loves -  cars, up to 20. 
3. **Build sentence:** When Brian opens the page, the page displays a random number of cars (up to a maximum of 20), and he counts the number of cars on screen, and clicks on one of three number choices (one correct, two incorrect), the build responds with confetti, a “Good job!” message, and +1 point if the answer is correct, or “Let’s count again!” with the points unchanged if it’s wrong. If he gets it correct, the page will refresh and show another set of cars, if the wrong answer is chosen, the same question is displayed again. 
4. **Boundary:** Never show a number above 20, never take away points, never use a timer that puts pressure on Brian, and never say the word “wrong” or show a red X. Messages should never be mean or scary for a child.
5. **Rejected idea:** I did not pick the idea of Brian typing in a number instead of choosing one from the screen, because Brian is too young to type numbers on a computer.