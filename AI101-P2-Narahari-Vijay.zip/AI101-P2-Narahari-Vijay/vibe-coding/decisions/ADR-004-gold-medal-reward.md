# ADR-004: Gold medal reward

**Status:** accepted (Class 18)

**Context:** In Cycle 1 and Cycle 2, Brian only earned points. Professor Madrid gave feedback to add gameplay rewards. I agree with this feedback because Brian will be encouraged to keep playing.

**Decision:** Brian earns a gold medal 🥇 for every 5 correct answers. The medals fill a board of 10 spots, in 2 rows of 5, under the score. When all 10 medals are earned, the game celebrates with confetti, and shows "Yay! You Are A Math Star!" then the score and the medal board reset to 0 so he can start again.

**Consequence:** Brian gets a new medal to be engaged in the game, and he can see his medals goal on the board. But filling in the board still takes 50 correct answers, the medal board needs room at the top without causing scrolling, and medals are lost if the page is closed, since nothing is saved.