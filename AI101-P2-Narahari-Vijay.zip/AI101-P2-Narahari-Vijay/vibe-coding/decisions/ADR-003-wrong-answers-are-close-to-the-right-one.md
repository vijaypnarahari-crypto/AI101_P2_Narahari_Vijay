# ADR-003: Wrong answers are close to the right one

**Status:** accepted (Class 17)

**Context:** In Cycle 1, the two wrong choices were picked at random from 1 to 20, so they were often far from the right answer (see tests/c1-issue-noticed.png, where the choices were 2, 11, and 20 for 11 cars). Brian could pick the right answer by looking instead of counting, which skips the skill the game is for.

**Decision:** The two wrong choices are always within 3 of the right answer (like 12 and 13 for 11), and all three numbers stay between 1 and 20.

**Consequence:** Brian has to actually count to tell the choices apart, so the game teaches counting instead of guessing. But the game gets harder, especially with many cars, so Brian may get more "Let's count again!" messages, and small numbers like 1 and 2 have fewer close choices to pick from.